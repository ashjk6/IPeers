import socket
import time
import threading

buffer = int(input("Max message size in bytes (Max 65535): "))
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(('127.0.0.1', 2010))
message = s.recv(buffer).decode("utf-8")
print(f"Server: {message}")

def sending_message():
    while True:
        try:
            send_message = input("Message to send: ")
            if send_message.lower() == "!exit":
                s.send(send_message.encode('utf-8'))
                time.sleep(1)
                s.close()
                break
            else:
                s.send(send_message.encode("utf-8"))
        except Exception as e:
            print(f"Send error: {e}")
            break

def receiving_message():
    while True:
        try:
            recv_message = s.recv(buffer).decode("utf-8")
            if recv_message.lower() == "!exit":
                print("Server disconnected!")
                time.sleep(1)
                s.close()
                break
            else:
                print(f"\nServer: {recv_message}\nMessage to send: ", end="", flush=True)
        except Exception as e:
            print(f"Receive error: {e}")
            break

threading.Thread(target=receiving_message, daemon=True).start()
sending_message()
