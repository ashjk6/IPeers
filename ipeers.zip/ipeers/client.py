import socket
import threading
import customtkinter as ctk

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

app = ctk.CTk()
app.geometry("500x700")
app.title("Client")

buffer = 0
s = None

def add_chat_message(msg):
    chat_log.configure(state="normal")
    chat_log.insert("end", msg + "\n")
    chat_log.see("end")
    chat_log.configure(state="disabled")

def receive_messages():
    while True:
        data = s.recv(buffer).decode('utf-8')
        add_chat_message(f"Server: {data}")

def connect_server():
    global s, buffer
    buffer = int(buffer_entry.get())
    ip = ip_entry.get()
    port = int(port_entry.get())
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((ip, port))
    threading.Thread(target=receive_messages, daemon=True).start()
    add_chat_message(f"Connected to server {ip}:{port} (TCP)")

def send_message():
    msg = message_entry.get()
    s.send(msg.encode('utf-8'))
    add_chat_message(f"You: {msg}")
    message_entry.delete(0, "end")

def stop_client():
    s.close()
    add_chat_message("Disconnected from server")

buffer_entry = ctk.CTkEntry(app, placeholder_text="Max message size (Max 65535)")
buffer_entry.pack(pady=5)

ip_entry = ctk.CTkEntry(app, placeholder_text="Server IP (e.g. 127.0.0.1)")
ip_entry.pack(pady=5)

port_entry = ctk.CTkEntry(app, placeholder_text="Port (e.g. 2010)")
port_entry.pack(pady=5)

chat_log = ctk.CTkTextbox(app, width=480, height=400, state="disabled")
chat_log.pack(pady=5)

message_entry = ctk.CTkEntry(app, placeholder_text="Type your message here...")
message_entry.pack(pady=5, fill="x")

send_button = ctk.CTkButton(app, text="Send", command=send_message)
send_button.pack(pady=5)

connect_button = ctk.CTkButton(app, text="Connect", command=connect_server)
connect_button.pack(pady=10)

stop_button = ctk.CTkButton(app, text="Disconnect", command=stop_client)
stop_button.pack(pady=10)

app.mainloop()
