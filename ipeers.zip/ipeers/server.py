import socket
import time
import threading
import os

buffer = int(input("Max message size in bytes (Max 65535): "))
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(('127.0.0.1', 2010))
s.listen(1)
print("Listening for incoming connections...")
client_socket, client_address = s.accept()
print(f"New connection from {client_address}")
client_socket.send("Hello from server!".encode('utf-8'))

def sending():
    while True:
        try:
            send_message = input("Message to send: ")
            if send_message.lower() == '!exit':
                client_socket.send(send_message.encode('utf-8'))
                time.sleep(1)
                client_socket.close()
                break
            else:
                client_socket.send(send_message.encode('utf-8'))
        except Exception as e:
            print(f"Send error: {e}")
            break

def receiving():
    while True:
        try:
            recv_message = client_socket.recv(buffer).decode('utf-8')
            if recv_message.lower() == '!exit':
                print("Client disconnected!")
                time.sleep(1)
                client_socket.close()
                break
            else:
                print(f"\nClient: {recv_message}\nMessage to send: ", end="", flush=True)
        except Exception as e:
            print(f"Receive error: {e}")
            break

threading.Thread(target=receiving, daemon=True).start()
sending()
