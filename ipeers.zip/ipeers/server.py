import socket
import threading
import customtkinter as ctk

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

app = ctk.CTk()
app.geometry("500x700")
app.title("Server")

buffer = 0
s = None
client_socket = None

def add_chat_message(msg):
    chat_log.configure(state="normal")
    chat_log.insert("end", msg + "\n")
    chat_log.see("end")
    chat_log.configure(state="disabled")

def receive_from_client():
    global client_socket
    while True:
        try:
            data = client_socket.recv(buffer).decode('utf-8')
            if not data:
                break
            add_chat_message(f"Client: {data}")
        except:
            break

def accept_client():
    global client_socket
    client_socket, addr = s.accept()
    add_chat_message(f"Client connected from {addr}")
    threading.Thread(target=receive_from_client, daemon=True).start()  # start receiving thread immediately

def accept_client_thread():
    threading.Thread(target=accept_client, daemon=True).start()

def start_server():
    global s, buffer, client_socket
    buffer = int(buffer_entry.get())
    port = int(port_entry.get())
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('127.0.0.1', port))
    s.listen(1)
    add_chat_message(f"Server started, listening on port {port} (TCP)")
    accept_client_thread()

def send_message():
    msg = message_entry.get()
    client_socket.send(msg.encode('utf-8'))
    add_chat_message(f"You: {msg}")
    message_entry.delete(0, "end")

def stop_server():
    client_socket.close()
    s.close()
    add_chat_message("Server stopped.")

buffer_entry = ctk.CTkEntry(app, placeholder_text="Max message size (Max 65535)")
buffer_entry.pack(pady=5)

port_entry = ctk.CTkEntry(app, placeholder_text="Port (e.g. 2010)")
port_entry.pack(pady=5)

chat_log = ctk.CTkTextbox(app, width=480, height=400, state="disabled")
chat_log.pack(pady=5)

message_entry = ctk.CTkEntry(app, placeholder_text="Type your message here...")
message_entry.pack(pady=5, fill="x")

send_button = ctk.CTkButton(app, text="Send", command=send_message)
send_button.pack(pady=5)

start_button = ctk.CTkButton(app, text="Start Server", command=start_server)
start_button.pack(pady=10)

stop_button = ctk.CTkButton(app, text="Stop Server", command=stop_server)
stop_button.pack(pady=10)

app.mainloop()
