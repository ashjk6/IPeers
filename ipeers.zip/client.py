import socket
import threading
import customtkinter as ctk
from tkinter import scrolledtext
from tkinter import END, NORMAL, DISABLED

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_connected = False

# --- CUSTOMTKINTER SETUP ---
ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

root = ctk.CTk()
root.title("IPeers Client")
root.geometry("600x450")
# root.iconbitmap("icon.ico") # customtkinter doesn't support .iconbitmap directly

# Configure grid for resizing
root.columnconfigure(0, weight=1)
root.columnconfigure(1, weight=0)
root.rowconfigure(0, weight=1)
root.rowconfigure(1, weight=0)

# Manually set colors for the tkinter ScrolledText to force a uniform look
CHAT_BG = "#000000"  # Black
CHAT_FG = "#FFFFFF"  # White

chat_area = scrolledtext.ScrolledText(
    root,
    state=DISABLED,
    wrap="word",
    bg=CHAT_BG,
    fg=CHAT_FG,
    insertbackground=CHAT_FG,
    font=ctk.CTkFont(family="Arial", size=12)
)
# Use grid for resizable layout. sticky="nsew" makes it fill the cell.
chat_area.grid(row=0, column=0, columnspan=2, padx=10, pady=(10, 5), sticky="nsew")

msg_entry = ctk.CTkEntry(root, placeholder_text="Type your message...", width=400)
# Place in row 1, column 0, and use sticky="ew" to fill horizontally
msg_entry.grid(row=1, column=0, padx=(10, 5), pady=(5, 10), sticky="ew")

def send_msg():
    global client_connected
    msg = msg_entry.get()
    if msg and client_connected:
        s.send(msg.encode('utf-8'))
        chat_area.config(state=NORMAL)
        chat_area.insert(END, f"You: {msg}\n")
        chat_area.see(END)
        chat_area.config(state=DISABLED)
        msg_entry.delete(0, END)

send_button = ctk.CTkButton(root, text="Send", command=send_msg)
# Place in row 1, column 1
send_button.grid(row=1, column=1, padx=(5, 10), pady=(5, 10), sticky="e")

def receive():
    global client_connected
    while client_connected:
        try:
            msg = s.recv(1024).decode('utf-8')
            if msg.lower() == "!exit":
                client_connected = False
                break
            chat_area.config(state=NORMAL)
            chat_area.insert(END, f"Server: {msg}\n")
            chat_area.see(END)
            chat_area.config(state=DISABLED)
        except:
            client_connected = False
            break

def connect_to_server():
    global client_connected
    try:
        s.connect(("127.0.0.1", 6060))
        client_connected = True
        chat_area.config(state=NORMAL)
        chat_area.insert(END, "Connected to server!\n")
        chat_area.see(END)
        chat_area.config(state=DISABLED)
        threading.Thread(target=receive, daemon=True).start()
    except Exception as e:
        chat_area.config(state=NORMAL)
        chat_area.insert(END, f"Failed to connect: {e}\n")
        chat_area.see(END)
        chat_area.config(state=DISABLED)

threading.Thread(target=connect_to_server, daemon=True).start()

root.mainloop()