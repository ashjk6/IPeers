import socket
import threading
import customtkinter as ctk
from tkinter import scrolledtext
from tkinter import END, NORMAL, DISABLED

port = 6060
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(("0.0.0.0", port))
s.listen(1)
client_socket = None

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

root = ctk.CTk()
root.title("IPeers Server")
root.geometry("600x450")
root.columnconfigure(0, weight=1)
root.columnconfigure(1, weight=0)
root.rowconfigure(0, weight=1)
root.rowconfigure(1, weight=0)

# The problematic color lines are removed to fix the AttributeError.
# The ScrolledText will now use system default colors (likely white background).
chat_area = scrolledtext.ScrolledText(
    root,
    state=DISABLED,
    wrap="word",
    font=ctk.CTkFont(family="Arial", size=12)
)
chat_area.grid(row=0, column=0, columnspan=2, padx=10, pady=(10, 5), sticky="nsew")

msg_entry = ctk.CTkEntry(root, placeholder_text="Type your message...", width=400)
msg_entry.grid(row=1, column=0, padx=(10, 5), pady=(5, 10), sticky="ew")

chat_area.insert(END, f"Server started on 0.0.0.0:{port}\n")

def send_msg():
    global client_socket
    msg = msg_entry.get()
    if msg and client_socket:
        client_socket.send(msg.encode('utf-8'))
        chat_area.config(state=NORMAL)
        chat_area.insert(END, f"You: {msg}\n")
        chat_area.see(END)
        chat_area.config(state=DISABLED)
        msg_entry.delete(0, END)

send_button = ctk.CTkButton(root, text="Send", command=send_msg)
send_button.grid(row=1, column=1, padx=(5, 10), pady=(5, 10), sticky="e")

def receive():
    global client_socket
    while True:
        try:
            msg = client_socket.recv(1024).decode('utf-8')
            if msg.lower() == "!exit":
                break
            chat_area.config(state=NORMAL)
            chat_area.insert(END, f"Client: {msg}\n")
            chat_area.see(END)
            chat_area.config(state=DISABLED)
        except:
            break

def accept_client():
    global client_socket
    client_socket, addr = s.accept()
    chat_area.config(state=NORMAL)
    chat_area.insert(END, f"Connected to: {addr}\n")
    chat_area.see(END)
    chat_area.config(state=DISABLED)
    threading.Thread(target=receive, daemon=True).start()

threading.Thread(target=accept_client, daemon=True).start()

root.mainloop()
